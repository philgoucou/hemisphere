#=======================================================#
# 0 - Initialization                                    #
#=======================================================#

rm(list = ls())

path = "~/Dropbox/Amnesic_NN/MacroNN/exemple/R/paper/" 

setwd(path)

## 0.1 - Load packages ------------------------------

library(torch)
library(stringr)
library(pracma)
library(ggplot2)
library(reshape2)
library(tidyr)

torch_set_num_threads(1) # use only 1 core in HNN estimation

## 0.2 - Graph Parameters ------------------------------

scaleFUN <- function(x) sprintf("%.2f", x)

recessions.df = read.table(textConnection(
  "Peak, Trough
    1960-04-01, 1961-02-01
    1969-12-01, 1970-11-01
    1973-11-01, 1975-03-01
    1980-01-01, 1980-07-01
    1981-07-01, 1982-11-01
    1990-07-01, 1991-03-01
    2001-03-01, 2001-11-01
    2007-12-01, 2009-06-01,
    2020-03-01, 2020-06-01"), sep=',',
  colClasses=c('Date', 'Date'), header=TRUE)

date_allSample <- seq.Date(as.Date('1961-06-01'), 
                           as.Date('2022-03-01'), 
                           by = "quarter")

## 0.3 - Load HNN function ----------------------------

source('HNN_function.R')

#=======================================================#
# 1 - Data                                              #
#=======================================================#

## 1.1 - Load data ------------------------------------

hnn_results <- list()
decomposition_results <- vector("list",1)
end <- "12/1/2019" # In-sample ends

# split data : training and test set
load("macrotoy_infh1_forecast_2022.RData")
newtrain <- newtrainALL

N <- dim(newtrain)[1]
Var<-dim(newtrain)[2]

newtrain=as.data.frame(newtrain)
train_index <- 1:((which(rownames(newtrain)==end)))
train_data <- newtrain[train_index,]
test_data <- newtrain[-train_index,]

form <- formula(y ~ .)
X <- model.matrix(form, data=train_data)[,-1]
Y <- train_data$y
Xtest <- model.matrix(form, data=test_data)[,-1]
Ytest <- test_data$y
oos.index <- (nrow(X)+1):(nrow(X)+nrow(Xtest))

## 1.2 - Make groups ------------------------------------

# Which lags to use ?
first_part <- c("L0_","L1_","L2_","L3_","L1_MARX_","L3_MARX_","L7_MARX_")

# Real activity
labor_name <- c("PAYEMS","USPRIV","MANEMP","SRVPRD","USGOOD" ,"DMANEMP","NDMANEMP","USCONS","USEHS",
                "USFIRE","USINFO","USPBS","USLAH","USSERV","USMINE","USTPU","USGOVT","USTRADE",
                "USWTRADE","CES9091000001","CES9092000001","CES9093000001","CE16OV","CIVPART",
                "UNRATE","UNRATESTx","UNRATELTx","LNS14000012","LNS14000025","LNS14000026",
                "UEMPLT5","UEMP5TO14","UEMP15T26","UEMP27OV","LNS13023621","LNS13023557",
                "LNS13023705","LNS13023569","LNS12032194","HOABS","HOAMS","HOANBS","AWHMAN",
                "AWHNONAG","AWOTMAN","HWIx","UEMPMEAN","CES0600000007", "HWIURATIOx","CLAIMSx",
                "GDPC1","PCECC96","GPDIC1","OUTNFB","OUTBS","OUTMS","INDPRO","IPFINAL","IPCONGD",
                "IPMAT","IPDMAT","IPNMAT","IPDCONGD","IPB51110SQ","IPNCONGD","IPBUSEQ","IPB51220SQ",
                "TCU","CUMFNS","IPMANSICS","IPB51222S","IPFUELS")

x_pos1 <- unlist(lapply(1:length(first_part),
                        function(i) unlist(lapply(1:length(labor_name), function(x) which(colnames(X)==paste0(first_part[i],labor_name[x]))))))

# Price (SR Expectations)
colnames(X)[1:4] <- c("L0_Y","L1_Y","L2_Y","L3_Y")
colnames(Xtest)[1:4] <- c("L0_Y","L1_Y","L2_Y","L3_Y")
price_name <- c("Y","PCECTPI","PCEPILFE","GDPCTPI","GPDICTPI","IPDBS",
                "CPILFESL","CPIAPPSL",
                "CPITRNSL","CPIMEDSL","CUSR0000SAC","CUSR0000SAD","WPSFD49207",
                "PPIACO","WPSFD49502","WPSFD4111","PPIIDC","WPSID61","WPSID62",
                "CUSR0000SAS","CPIULFSL","CUSR0000SA0L2","CUSR0000SA0L5","CUSR0000SEHC",
                "spf_cpih1","spf_cpi_currentYrs","inf_mich")

x_pos2 <- unlist(lapply(1:length(first_part),
                        function(i) unlist(lapply(1:length(price_name), function(x) which(colnames(X)==paste0(first_part[i],price_name[x]))))))

# Commodities
commodities_name <- c("WPU0531",
                      "WPU0561","OILPRICEx","PPICMM")

x_pos3 <- unlist(lapply(1:length(first_part),
                        function(i) unlist(lapply(1:length(commodities_name), function(x) which(colnames(X)==paste0(first_part[i],commodities_name[x]))))))

# Trend (LR Expectations)
x_pos4 = c(ncol(X)) # linear trend

#=======================================================#
# 2 - HNN Estimation                                    #
#=======================================================#

## 2.1 - Set HNN parameters ----------------------------

# Uncomment to see VI for the hemisphere 
variable_importance <- vector("list",length = 3)
# variable_importance[[1]] <- labor_name
# variable_importance[[2]] <- price_name
# variable_importance[[3]] <- commodities_name

x_pos <- list()
x_pos[[1]] <- x_pos1 # Real activity hemisphere
x_pos[[2]] <- x_pos2 # SR Expectations hemisphere
x_pos[[3]] <- x_pos3 # Commodities hemisphere
x_pos[[4]] <- x_pos4 # LR Expectations hemisphere
x_pos[[5]] <- x_pos4 # Trend(time varying coefficient) associate to hemisphere 1
x_pos[[6]] <- x_pos4 # Trend(time varying coefficient) associate to hemisphere 2
x_pos[[7]] <- x_pos4 # Trend(time varying coefficient) associate to hemisphere 3

nodes <- list()
nodes[[1]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 1
nodes[[2]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 2
nodes[[3]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 3
nodes[[4]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 4
nodes[[5]] <- rep(100,3) # Number of neurons and hidden layers for the trend in hemisphere 1
nodes[[6]] <- rep(100,3) # Number of neurons and hidden layers for the trend in hemisphere 2
nodes[[7]] <- rep(100,3) # Number of neurons and hidden layers for the trend in hemisphere 3

nn_hyps <- list(n_features=c(length(x_pos1),length(x_pos2),
                             length(x_pos3) ,
                             length(x_pos4),
                             length(x_pos4),
                             length(x_pos4),
                             length(x_pos4),
                             length(x_pos4)),
                nodes=nodes,             
                patience=50,              # Number of epochs before stopping once your loss starts to increase (Return the best model)
                epochs=500,               # Maximum number of epochs
                lr= 0.05,                 # Learning rate
                show_train=2,             # 1=show each bootstrap loss, 2=progress bar, 3+=show nothing
                num_average=300,           # Number of bootstrap
                sampling_rate = 0.85,     # In-sample sampling rate
                x_pos = x_pos,            
                tol = 0.01,               # Early stopping criteria tolerance
                dropout_rate=0.2,         # Dropout rate in each layers
                block_size=6,             
                opt_bootstrap=2,         
                add_trends_to=c(1:3),     # Add trend (time varying coefficient) to hemispheres 1 to 3
                variable_importance=variable_importance, 
                first_part=first_part)

## 2.2 - HNN Estimation ----------------------------

s <- Sys.time()
test <- HNN(X,Y,Xtest,Ytest,nn_hyps,standardize=T,seed=1234)
e <- Sys.time()
print(e-s)

#=======================================================#
# 3 - Results                                           #
#=======================================================#

## 3.1 - Analyze forecast components -------------------

group_name <- c("Labor","Price","Commodities","Trend")
x_pos <- list()
x_pos[[1]] <- x_pos1
x_pos[[2]] <- x_pos2
x_pos[[3]] <- x_pos3
x_pos[[4]] <- x_pos4

# Gather in-sample results
data <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(X))

for(i in 1:length(x_pos)) {
  data[,i] <- rowMeans(test$part.pred.in[,i,], na.rm = T)
}

forecast_decomp_in <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(X))
for(i in 1:nrow(forecast_decomp_in)) {
  forecast_decomp_in[i,] <- data[i,]
}
colnames(forecast_decomp_in) <- group_name

# Gather OOS results
data <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(Xtest))

for(i in 1:length(x_pos)) {
  data[,i] <- rowMeans(test$part.pred[,i,])
}

forecast_decomp_oos <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(Xtest))
for(i in 1:nrow(forecast_decomp_oos)) {
  forecast_decomp_oos[i,] <- data[i,]
}
colnames(forecast_decomp_oos) <- group_name

decomposition_results[[1]][[1]] <- forecast_decomp_in
decomposition_results[[1]][[2]] <- forecast_decomp_oos

# Make plot
forecast_decomp_in <- decomposition_results[[1]][[1]]*400
forecast_decomp_oos <- decomposition_results[[1]][[2]]*400

oos.index <- nrow(forecast_decomp_in)

# Real Activity
alt <- rbind(test$part.pred.in[,1,],test$part.pred[,1,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- c(forecast_decomp_in[,1],forecast_decomp_oos[,1])
df <- gather(data.frame("Real Activity"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df1 <- cbind(df,date,df_quantile)

# Short-Run Expectations
alt <- rbind(test$part.pred.in[,2,],test$part.pred[,2,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- c(forecast_decomp_in[,2],forecast_decomp_oos[,2])
df <- gather(data.frame("SR Expectations"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df2 <- cbind(df,date,df_quantile)

# Commodities
alt <- rbind(test$part.pred.in[,3,],test$part.pred[,3,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- c(forecast_decomp_in[,3],forecast_decomp_oos[,3])
df <- gather(data.frame(Commodities=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df3 <- cbind(df,date,df_quantile)

# Long-Run Expectations (trend)
alt <- rbind(test$part.pred.in[,4,],test$part.pred[,4,]) + mean(Y)
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- c(forecast_decomp_in[,4],forecast_decomp_oos[,4]) + mean(Y)*400
df <- gather(data.frame("LR Expectations"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df4 <- cbind(df,date,df_quantile)

alt <- as.data.frame(rbind(df1,df2,df3,df4))

alt[which(alt[,1] == "Real.Activity"),1] <- "Real Activity"
alt[which(alt[,1] == "SR.Expectations"),1] <- "SR Expectations"
alt[which(alt[,1] == "LR.Expectations"),1] <- "LR Expectations"

test.long <- alt
test.long[,1] <- factor(test.long[,1], levels = c("Real Activity","SR Expectations","Commodities","LR Expectations"))

p=ggplot(data = test.long, 
         mapping = aes(x = Date, y =value, color= Group)) +
  geom_line(size=1.5)+
  facet_wrap(~(Group), ncol = 2, scales = 'free') +
  geom_ribbon(aes(ymin=Min, ymax=Max), 
              alpha = 0.30, colour = NA) +  
  theme_bw()+
  xlab('')+ylab('')+labs(color='')+
  scale_x_date(breaks = scales::pretty_breaks(n = 8),date_labels = "%Y", expand = c(0.01,0.01))+
  geom_vline(xintercept =date_allSample[oos.index],linetype="dashed",size=1.35)+
  geom_hline(yintercept =0,size=c(0.6,0.6,0.6,0.6),colour=c('grey29','grey29','grey29','white'))+
  theme(axis.text.x=element_text(size=24,angle = 0,hjust=1),
        axis.text.y=element_text(size=24),
        strip.text = element_text(face="bold", size=30),
        legend.text=element_text(size=30),
        legend.position='bottom'
  ) +
  geom_rect(data=subset(recessions.df, Peak >= min(test.long$Date)),
            inherit.aes=FALSE,aes(xmin=Peak, xmax=Trough,
                                  ymin=-Inf, ymax=+Inf), fill='pink', alpha=0.3)

p
# ptitle = paste("hnn_components.png",sep='')
# ggsave(ptitle, dpi=dpi, dev='png', height=400, width=650, units="mm",scale=0.85)

## 3.2 - Model fit --------------------------------
pred <- data.frame("Fitted values" = c(test$pred.in, rep(NA, length(test$pred))),
                   "Forecasts" = c(rep(NA, length(test$pred.in)), test$pred),
                   "Realized"=c(Y, Ytest))*400
rownames(pred) <- as.Date(date_allSample, tryFormats = "%m/%d/%Y")
colnames(pred) <- c("Fitted values","Forecasts","Realized")
pred <- as.matrix(pred)

test.long <- reshape2::melt(pred)
test.long$Var1 =  as.Date(test.long$Var1)

p=ggplot() +
  geom_line(data = test.long,
            aes(x =Var1 , y =value,color=Var2), size = 1)+ 
  theme_bw()+
  ggtitle("HNN Forecasts") +
  xlab('Date')+ylab('Annualized Inflation rate (%)')+labs(color='')+
  geom_vline(xintercept =date_allSample[oos.index],linetype="dashed",size=1.35)+
  theme(axis.text.x=element_text(size=13,angle = 0,hjust=1),
        axis.text.y=element_text(size=13),
        strip.text = element_text(face="bold", size=15),
        legend.text=element_text(size=15),
        legend.position='bottom'
  ) +
  scale_color_manual(values=c("blue","red","black")) + 
  geom_rect(data=subset(recessions.df, Peak >= min(test.long$Var1)),
            inherit.aes=FALSE,aes(xmin=Peak, xmax=Trough,
                                  ymin=-Inf, ymax=+Inf), fill='pink', alpha=0.3)
p
# ptitle = paste("hnn_fitted_values.png",sep='')
# ggsave(ptitle, dpi=dpi, dev='png', height=400, width=650, units="mm",scale=0.85)