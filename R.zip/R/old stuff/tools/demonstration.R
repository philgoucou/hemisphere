# Multiply each coefs with gaps -----
num_average <- 50
components = array(data = NA, dim = c(nrow(newtrainALL),4,num_average))
pred <- array(data = NA, dim = c(nrow(newtrainALL),num_average))
sigma_y <- test$scaler$sigma_y
mu_y <- test$scaler$mu_y


for(i in 1:num_average) { # Each bootstraps (same number as "num_average')
  for(j in 1:3) { # Each hemisphere
    
    components[,j,i] <- ((c(test$gaps.in[,j,i], test$gaps[,j,i])/sigma_y) *
                        (c(test$trends.in[,j,i], test$trends[,j,i])/sigma_y))
  
  }
  
  components[,4,i] <- (c(test$part.pred.in[,4,i], test$part.pred[,4,i])/sigma_y) # add LR expectations
  
  # Scale results to match the HNN's output
  pred[,i] <- (rowSums(components[,,i]) * sigma_y) + mu_y
  components[,,i] <- components[,,i]*sigma_y
  
}

# Mean -----
pos <- 1 # Which components
components_constructed <- rowMeans(components[,pos,], na.rm = T)
components_hnn <- rowMeans(rbind(test$part.pred.in[,pos,], test$part.pred[,pos,]), na.rm = T)

pred_constructed <- rowMeans(pred, na.rm = T)
pred_hnn <- c(test$pred.in, test$pred)

# Plot, to see the components -----
plot(components_constructed, type = 'l', lwd = 2)
lines(components_hnn, lwd = 2, col = 2)

results <- data.frame("FromModelOutput" = components_hnn, "Constructed" = components_constructed)
print(results)

# Plot, to see the forecasts -----
plot(pred_constructed, type = 'l', lwd = 2)
lines(pred_hnn, lwd = 2, col = 2)

results <- data.frame("FromModelOutput" = pred_hnn, "Constructed" = pred_constructed)
print(results)

