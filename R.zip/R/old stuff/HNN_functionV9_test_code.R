rm(list = ls())
# install.packages("torch")

#path <- "/Users/UQAM/Dropbox/Amnesic_NN/MacroNN/"
path <- "C:/Users/Hugo9/Dropbox/Hugo/torch_tuto/MacroNN/"
path = "~/Dropbox/Amnesic_NN/MacroNN/" #MNN_example/"

setwd(path)

library(torch)
library(fbi)
library(ranger)
library(forecast)
library(stringr)
library(lubridate)
library(forecast)
library(pracma)
library(ggplot2)
library(reshape2)
library(matrixcalc)
library(abind)
library(RColorBrewer)
library(ggthemes)
library(DescTools)
library(grid)
library(wesanderson)
library(dplR)
library(hrbrthemes)
library(viridis)
library(tidyr)

torch_set_num_threads(1)

## LOAD FUNCTIONS --------------------------------------------------------------
# ==============================================================================

source("MLP_function_v4.R")
#source("HNN_function_v8d_VI.R")

r.squared.fair = function(pred, actual,y.is) {
  rss <- sum((actual-pred)^2)
  tss <- sum((actual-mean(y.is))^2)
  rsq=1-rss/tss
  #if(rsq< -0.5){rsq=-0.5}
  return(rsq)
}

rol.mean = function(Y,period) {
  out <- unlist(lapply((period+1):length(Y), function(x) mean(Y[(x-period):(x-1)], na.rm = T)))
  out <- c(rep(NA,period),out)
  return(out)
}

## LOAD DATA -------------------------------------------------------------------
# ==============================================================================

estimation_end <- c("3/1/2000","3/1/2007","3/1/2017","12/1/2019","9/1/2021")
graph_name <- c("03-01-2000","03-01-2007","03-01-2017","12-01-2019","09-01-2021")

hnn_results <- list()
decomposition_results <- vector("list",length(estimation_end))

for (estim_end in 4) {
  end <- estimation_end[estim_end]
  
  ## split data
  load("updated_data/macrotoy_infh1_forecast_2022.RData")
  newtrain <- newtrainALL
  
  N <- dim(newtrain)[1]
  Var<-dim(newtrain)[2]
  
  # time.dum = matrix(0,4,nrow(newtrain))
  # time.dum[1,1:35]=1
  # time.dum[2,36:75]=1
  # time.dum[3,76:115]=1
  # time.dum[4,116:ncol(time.dum)]=1
  # time.dum = t(time.dum)
  # colnames(time.dum)=c('sixties','seventies','eighties','ninetiesandbeyond')
  # 
  newtrain=as.data.frame(newtrain)
  #newtrain[,1]=newtrain[,1]+0.003*newtrain[,257]
  train_index <- 1:((which(rownames(newtrain)==end)))
  train_data <- newtrain[train_index,]
  test_data <- newtrain[-train_index,]
  
  form <- formula(y ~ .)
  X <- model.matrix(form, data=train_data)[,-1]
  Y <- train_data$y
  Xtest <- model.matrix(form, data=test_data)[,-1]
  # dim(Xtest) <- c(nrow(test_data),ncol(test_data[,-1]))
  # colnames(Xtest) <- colnames(test_data[,-1])
  Ytest <- test_data$y
  oos.index <- (nrow(X)+1):(nrow(X)+nrow(Xtest))
  
  ## MAKE GROUPS ----------------------------------------------------------------
  # =============================================================================
  
  # nipa_name <- c("GDPC1","PCECC96","PCDGx","PCESVx","PCNDx","GPDIC1","FPIx","Y033RC1Q027SBEAx",
  #                "PNFIx","PRFIx","A014RE1Q156NBEA","GCEC1","A823RL1Q225SBEA","FGRECPTx","SLCEx","EXPGSC1",         
  #                "IMPGSC1","DPIC96","OUTNFB","OUTBS","OUTMS","B020RE1Q156NBEA","B021RE1Q156NBEA" )
  # indus_prod_name <- c("INDPRO","IPFINAL","IPCONGD","IPMAT","IPDMAT","IPNMAT","IPDCONGD","IPB51110SQ",
  #                      "IPNCONGD","IPBUSEQ","IPB51220SQ","TCU","CUMFNS","IPMANSICS","IPB51222S","IPFUELS")
  # housing_name <- c("HOUST","HOUST5F","PERMIT","HOUSTMW","HOUSTNE","HOUSTS","HOUSTW","USSTHPI",
  #                   "SPCS10RSA","SPCS20RSA","PERMITNE","PERMITMW","PERMITS","PERMITW")
  # sales_name <- c("CMRMTSPLx","RSAFSx","AMDMNOx","ACOGNOx","AMDMUOx","ANDENOx","INVCQRMTSPL","BUSINVx","ISRATIOx")
  # earnings_name <- c("AHETPIx","CES2000000008x","CES3000000008x","COMPRMS","COMPRNFB","RCPHBS","OPHMFG","OPHNFB",
  #                    "OPHPBS","ULCBS","ULCMFG","ULCNFB","UNLPNBS","CES0600000008" )
  # rates_name <- c("FEDFUNDS","TB3MS","TB6MS","GS1","GS10","MORTGAGE30US","AAA","BAA","BAA10YM","MORTG10YRx",
  #                 "TB6M3Mx","GS1TB3Mx","GS10TB3Mx","CPF3MTB3Mx","GS5","TB3SMFFM","T5YFFM","AAAFFM","CP3M","COMPAPFF")
  # credit_name <- c("BOGMBASEREALx","IMFSLx","M1REAL","M2REAL","MZMREAL","BUSLOANSx","CONSUMERx","NONREVSLx",
  #                  "REALLNx","REVOLSLx","TOTALSLx","DRIWCIL","TOTRESNS","NONBORRES","DTCOLNVHFNM","DTCTHFNM","INVEST")
  # household_bal_sheet_name <- c("TABSHNOx","TLBSHNOx","LIABPIx","TNWBSHNOx","NWPIx","TARESAx","HNOREMQ027Sx","TFAABSHNOx","CONSPIx")
  # non_household_bal_sheet_name <- c("GFDEGDQ188S","GFDEBTNx","TLBSNNCBx","TLBSNNCBBDIx","TTAABSNNCBx","TNWMVBSNNCBx",
  #                                   "TNWMVBSNNCBBDIx","TLBSNNBx","TLBSNNBBDIx","TABSNNBx","TNWBSNNBx","TNWBSNNBBDIx","CNCFx")
  # stock_name <- c("VXOCLSx","NIKKEI225","NASDAQCOM","S.P.500","S.P..indust","S.P.div.yield","S.P.PE.ratio")
  # ex_rates_name <- c("TWEXAFEGSMTHx","EXUSEU", "EXSZUSx","EXJPUSx","EXUSUKx","EXCAUSx")
  # other_name <- c("UMCSENTx","USEPUINDXM")
  # price_name <- c("PCECTPI","PCEPILFE","GDPCTPI","GPDICTPI","IPDBS","DGDSRG3Q086SBEA","DDURRG3Q086SBEA",
  #                 "DSERRG3Q086SBEA","DNDGRG3Q086SBEA","DHCERG3Q086SBEA","DMOTRG3Q086SBEA","DFDHRG3Q086SBEA",
  #                 "DREQRG3Q086SBEA","DODGRG3Q086SBEA","DFXARG3Q086SBEA","DCLORG3Q086SBEA","DGOERG3Q086SBEA",
  #                 "DONGRG3Q086SBEA","DHUTRG3Q086SBEA","DHLCRG3Q086SBEA","DTRSRG3Q086SBEA","DRCARG3Q086SBEA",
  #                 "DFSARG3Q086SBEA","DIFSRG3Q086SBEA","DOTSRG3Q086SBEA","CPIAUCSL","CPILFESL","WPSFD49207",
  #                 "PPIACO","WPSFD49502","WPSFD4111","PPIIDC","WPSID61","WPU0531","WPU0561","OILPRICEx",
  #                 "WPSID62","PPICMM","CPIAPPSL","CPITRNSL","CPIMEDSL","CUSR0000SAC","CUSR0000SAD",
  #                 "CUSR0000SAS","CPIULFSL","CUSR0000SA0L2","CUSR0000SA0L5","CUSR0000SEHC")
  
  first_part <- c("L0_","L1_","L2_","L3_","L1_MARX_","L3_MARX_","L7_MARX_")
  
  # LABOR
  labor_name <- c("PAYEMS","USPRIV","MANEMP","SRVPRD","USGOOD" ,"DMANEMP","NDMANEMP","USCONS","USEHS",
                  "USFIRE","USINFO","USPBS","USLAH","USSERV","USMINE","USTPU","USGOVT","USTRADE",
                  "USWTRADE","CES9091000001","CES9092000001","CES9093000001","CE16OV","CIVPART",
                  "UNRATE","UNRATESTx","UNRATELTx","LNS14000012","LNS14000025","LNS14000026",
                  "UEMPLT5","UEMP5TO14","UEMP15T26","UEMP27OV","LNS13023621","LNS13023557",
                  "LNS13023705","LNS13023569","LNS12032194","HOABS","HOAMS","HOANBS","AWHMAN",
                  "AWHNONAG","AWOTMAN","HWIx","UEMPMEAN","CES0600000007", "HWIURATIOx","CLAIMSx",
                  "GDPC1",
                  "PCECC96","GPDIC1","OUTNFB","OUTBS","OUTMS","INDPRO","IPFINAL","IPCONGD","IPMAT","IPDMAT",
                  "IPNMAT","IPDCONGD","IPB51110SQ","IPNCONGD","IPBUSEQ","IPB51220SQ","TCU","CUMFNS",
                  "IPMANSICS","IPB51222S","IPFUELS"
                  #,'ULCBS','ULCMFG','ULCNFB'
  ) #,'outputGap','unempGap')
  #labor_name <- c(  "UNRATE")
  x_pos1 <- unlist(lapply(1:length(first_part),
                          function(i) unlist(lapply(1:length(labor_name), function(x) which(colnames(X)==paste0(first_part[i],labor_name[x]))))))
  #x_pos1 <- c(x_pos1) # add trend
  #print(colnames(X)[x_pos1])
  #Xtemp=rbind(X,Xtest)
  #for(igi in 1:length(x_pos1)){
  #  Xtemp[,x_pos1[igi]]=cumsum(Xtemp[,x_pos1[igi]])
  #}
  #X=Xtemp[train_index,] 
  #Xtest=Xtemp[-train_index,] 
  #x_pos1 <- c(x_pos1,ncol(X))
  
  # PRICE
  colnames(X)[1:4] <- c("L0_Y","L1_Y","L2_Y","L3_Y")
  colnames(Xtest)[1:4] <- c("L0_Y","L1_Y","L2_Y","L3_Y")
  price_name <- c("Y","PCECTPI","PCEPILFE","GDPCTPI","GPDICTPI","IPDBS",
                  "CPILFESL","CPIAPPSL",
                  "CPITRNSL","CPIMEDSL","CUSR0000SAC","CUSR0000SAD","WPSFD49207",
                  "PPIACO","WPSFD49502","WPSFD4111","PPIIDC","WPSID61","WPSID62",
                  "CUSR0000SAS","CPIULFSL","CUSR0000SA0L2","CUSR0000SA0L5","CUSR0000SEHC",
                  "spf_cpih1","spf_cpi_currentYrs","inf_mich") # no commodities
  x_pos2 <- unlist(lapply(1:length(first_part),
                          function(i) unlist(lapply(1:length(price_name), function(x) which(colnames(X)==paste0(first_part[i],price_name[x]))))))
  x_pos2 <- c(x_pos2) # add trend
  print(colnames(X)[x_pos2])
  
  # COMMODITIES
  commodities_name <- c("WPU0531",
                        "WPU0561","OILPRICEx","PPICMM")
  
  x_pos3 <- unlist(lapply(1:length(first_part),
                          function(i) unlist(lapply(1:length(commodities_name), function(x) which(colnames(X)==paste0(first_part[i],commodities_name[x]))))))
  x_pos3 <- c(x_pos3) # add trend
  print(colnames(X)[x_pos3])
  
  # TREND
  x_pos4 = c(ncol(X))
  
  
  ## HNN ESTIMATION --------------------------------------------------------------
  # ==============================================================================
  test <- list()
  
  s <- Sys.time()
  variable_importance <- vector("list",length = 3)
  #variable_importance[[1]] <- labor_name
  #variable_importance[[2]] <- price_name
  # variable_importance[[3]] <- commodities_name
  
  x_pos <- list()
  x_pos[[1]] <- x_pos1
  x_pos[[2]] <- x_pos2
  x_pos[[3]] <- x_pos3
  x_pos[[4]] <- x_pos4
  x_pos[[5]] <- x_pos4
  x_pos[[6]] <- x_pos4
  x_pos[[7]] <- x_pos4
  
  nodes <- list()
  nodes[[1]] <- rep(400,3)
  nodes[[2]] <- rep(400,3)
  nodes[[3]] <- rep(400,3)
  nodes[[4]] <- rep(400,3)
  nodes[[5]] <- rep(100,3)
  nodes[[6]] <- rep(100,3)
  nodes[[7]] <- rep(100,3)
  
  #source("HNN_function_v7.R")
  #source("HNN_function_v8d_VI.R")
  #source("test_HNN_v8d.R")
  source('HNN_function_v9_VI_hugo.R')
  nn_hyps <- list(n_features=c(length(x_pos1),length(x_pos2),
                               length(x_pos3) ,
                               length(x_pos4),
                               length(x_pos4),
                               length(x_pos4),
                               length(x_pos4),
                               length(x_pos4)),
                  nodes=nodes,              # same number of nodes in every groups
                  patience=50,                   # Return the best model
                  epochs=500,
                  lr= 0.05, #0.02,
                  show_train=2,                  # 1=show each bootstrap loss, 2=progress bar, 3+=show nothing
                  num_average=20,
                  sampling_rate = 0.85,
                  x_pos = x_pos,
                  tol = 0.01,
                  dropout_rate=0.0,
                  block_size=6,
                  opt_bootstrap=2,
                  add_trends_to=c(1:3),
                  variable_importance=variable_importance,
                  first_part=first_part,
                  always_oob=c(140:145))
  
  test <- HNN(X,Y,Xtest,Ytest,nn_hyps,standardize=T,seed=1234)
  e <- Sys.time()
  print(e-s)
} # ESTIMATION END



x_pos <- list()
x_pos[[1]] <- x_pos1
x_pos[[2]] <- x_pos2
x_pos[[3]] <- x_pos3
x_pos[[4]] <- x_pos4
hnn_results[[1]] <- test

# FORECAST DECOMPOSITION --------------------------------------------

group_name <- c("Labor","Price","Commodities","Trend")

# IN SAMPLE
data <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(X))

for(i in 1:length(x_pos)) {
  data[,i] <- rowMeans(test$part.pred.in[,i,], na.rm = T)
}

forecast_decomp_in <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(X))
for(i in 1:nrow(forecast_decomp_in)) {
  forecast_decomp_in[i,] <- data[i,]
}
colnames(forecast_decomp_in) <- group_name

# OOS
data <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(Xtest))

for(i in 1:length(x_pos)) {
  data[,i] <- rowMeans(test$part.pred[,i,])
}

forecast_decomp_oos <- matrix(data = NA, ncol = length(x_pos), nrow = nrow(Xtest))
for(i in 1:nrow(forecast_decomp_oos)) {
  forecast_decomp_oos[i,] <- data[i,]
}
colnames(forecast_decomp_oos) <- group_name

decomposition_results[[1]][[1]] <- forecast_decomp_in
decomposition_results[[1]][[2]] <- forecast_decomp_oos

#save.image(file = "main_results/hnn_benchmark_infh1_forecast_2019.RData")
#.rs.restartR()

