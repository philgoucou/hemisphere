HNN <- function(X,Y,Xtest,Ytest,nn_hyps,standardize,seed) {
  
  # V2 : add predict function
  # V3 : add the parameter "tol" in the early stopping (percent change) +
  #      fix in case "sampling_rate" = 1
  # V4 : add dropout
  # V5 : allow for more than 2 groups +
  #      change function name to HNN (Hemisphere Neural Net, previously named WeirdNN)
  # V7 : add bootstrap_opt (out of bag)
  # V8 : multiply each hemisphere output by a trend
  # V9 : add "always.oob"
  # V10 : Return best_model fixed
  
  set.seed(seed)
  
  show_train=nn_hyps$show_train
  varNames <- colnames(X)
  
  if(show_train < 3) {
    
    cat("\nProgress : \n")
    cat(rep("-",40), sep = "")
    cat("\n \n")
    
  }
  
  
  # If needed scale data
  temp <- c()
  
  if(standardize==T) {
    
    if(show_train < 3) {
      cat("Standardize Data !!!! \n \n")
    }
    
    Y.ori=Y
    temp=scale_data(Xtrain = X, Ytrain = Y, Xtest = Xtest, Ytest = Ytest)
    X=temp$Xtrain
    Xtest=temp$Xtest
    
    Ytest = temp$Ytest
    Y = temp$Ytrain
    
  }
  
  # Convert our input data and labels into tensors.
  x_train = torch_tensor(X, dtype = torch_float(), requires_grad = F)
  y_train = torch_tensor(Y, dtype = torch_float(), requires_grad = F)
  x_test = torch_tensor(Xtest, dtype = torch_float(), requires_grad = F)
  y_test = torch_tensor(Ytest, dtype = torch_float(), requires_grad = F)
  
  # =====================================================================================================
  ## MNN MODEL
  # =====================================================================================================
  
  if(show_train < 3) {
    cat("Initialize Model !!!!! \n \n") 
  }
  
  BuildNN <- function(X,Y,training_index,nn_hyps) {
    
    # Setting up hyperparameters
    lr=nn_hyps$lr
    epochs=nn_hyps$epochs
    patience=nn_hyps$patience
    tol=nn_hyps$tol
    
    #training_index=training_index  
    show_train=nn_hyps$show_train
    
    # Build Model
    net = nn_module(
      "nnet",
      
      initialize = function(n_features=nn_hyps$n_features, nodes=nn_hyps$nodes,x_pos=nn_hyps$x_pos,dropout_rate=nn_hyps$dropout_rate,
                            add_trends_to = nn_hyps$add_trends_to){
        
        # Group index
        n_group = length(x_pos)# - length(add_trends_to)
        n_by_group <- list()
        
        x_indices = list()
        for(i in 1:n_group) {
          x_indices[[i]] = torch_tensor(c(x_pos[[i]]), dtype = torch_int64())
          n_by_group[[i]] = torch_tensor(sqrt(length(x_pos[[i]])))
          
        }
        self$x_indices = x_indices
        
        # Input layers
        self$input <- nn_module_list(lapply(1:n_group, function(x) nn_linear(n_features[x], nodes[[x]][1])))
        
        self$first <- list()
        self$hidden <- list()
        self$output <- list()
        
        for(i in 1:n_group) {
          
          # Hidden layers
          if(length(nodes)==1) {
            self$first[[i]] = nn_linear(nodes[[i]][1],nodes[[i]][1])
          }else{
            self$first[[i]] = nn_linear(nodes[[i]][1],nodes[[i]][1])
            self$hidden[[i]] = nn_module_list(lapply(1:(length(nodes[[i]])-1), function(x) nn_linear(nodes[[i]][x], nodes[[i]][x+1])))
          }
          
          # Output layer
          self$output[[i]] = nn_linear(nodes[[i]][length(nodes[[i]])],1)
        }
        
        self$dropout = nn_dropout(p=dropout_rate)
        self$dropout_in = nn_dropout(p=dropout_rate)
        self$n_group = n_group
        self$n_layers = length(nodes[[1]])
        self$add_trends_to = add_trends_to
        self$n_add_trends_to = length(add_trends_to)
        self$n_by_group = n_by_group
        
      },
      
      forward = function(x){
        
        
        # Set up
        dat = list()
        xx = list()
        for (i in 1:self$n_group) {
          dat[[i]] = torch_index_select(x,2,self$x_indices[[i]])
          dat[[i]] = torch_div(dat[[i]],self$n_by_group[[i]])
          
        }
        
        
        # Input
        for (i in 1:self$n_group) {
          xx[[i]] = torch_relu(self$input[[i]](dat[[i]]))
          #xx[[i]] = self$dropout_in(xx[[i]])
        }
        
        # Hidden
        for (i in 1:self$n_group) {
          xx[[i]] = torch_relu(self$first[[i]](xx[[i]]))
          xx[[i]] = self$dropout(xx[[i]])
          
        }
        
        if(self$n_layers>1) {
          
          for(i in 1:self$n_group) {
            for(layer in 1:(self$n_layers-1)) {
              xx[[i]] = torch_relu(self$hidden[[i]][[layer]](xx[[i]]))
              xx[[i]] = self$dropout(xx[[i]])
              
            }
          }
          
        }
        
        # Output
        for (i in 1:self$n_group) {
          xx[[i]] = self$output[[i]](xx[[i]])
        }
        
        trends = xx[(self$n_group-self$n_add_trends_to+1):self$n_group]
        xx = xx[1:(self$n_group-self$n_add_trends_to)]
        

        # Trends and gaps tranformation for better identification
        trends_mean = rep(1,length(trends))
        for(i in 1:length(trends)) {
          trends[[i]] = torch_abs(trends[[i]]) #trends absolute value
          aa=torch_mean(trends[[i]])
          trends[[i]] = torch_div(trends[[i]],aa) #exponential
          trends_mean[i]=as.matrix(aa)[1]
        }
        gaps_alt = xx
        
        # Multiply trends and gaps
        pos <- 1
        for(i in self$add_trends_to) {
          xx[[i]] = torch_mul(xx[[i]],trends[[pos]])
          pos <- pos + 1
        }
        
        gaps = gaps_alt[[1]]
        components = xx[[1]]
        for(i in 2:(self$n_group-self$n_add_trends_to)) {
          components = torch_hstack(list(components,xx[[i]]))
          gaps = torch_hstack(list(gaps,gaps_alt[[i]]))
        }
        
        alt = trends[[1]]
        for (i in 2:self$n_add_trends_to) {
          alt = torch_hstack(list(alt,trends[[i]]))
        }
        trends=alt
        
        yhat = torch_sum(components, dim = 2)
        
        # Results
        result = list(yhat,components,trends,gaps,trends_mean)
        return(result)
      }
      
    )
    
    model = net()
    
    ## Train model ---------------------------------------------------------------
    # ----------------------------------------------------------------------------
    
    patience = patience
    wait = 0
    oob_index <- c(1:x_train$size()[1])[-training_index]
    
    best_epoch = 0
    best_loss = NA
    
    criterion = nn_mse_loss()
    optimizer = optim_adam(model$parameters, lr = lr)
    
    for (i in 1:epochs) {
      
      optimizer$zero_grad() # Start by setting the gradients to zero
      
      y_pred=model(x_train[training_index,])[[1]]
      loss=criterion(y_pred,y_train[training_index])
      
      model$eval()
      with_no_grad({
        y_pred_oob=model(x_train[oob_index,])[[1]]
        loss_oob=criterion(y_pred_oob,y_train[oob_index])
        
        if(x_train$size()[1] == length(training_index)) {
          loss_oob=criterion(y_pred,y_train[training_index])
        }
      })
      model$train()
      
      percentChange <- ((best_loss - loss_oob$item())/loss_oob$item())
      
      # Early Stopping
      if(best_loss > loss_oob$item() | i == 1) { #best_loss > loss_oob$item()
        best_loss=loss_oob$item()
        best_epoch=i
        best_model=model
        #state_best_model <- lapply(model$state_dict(), function(x) x$clone()) 
        
        #print(model(x_train[training_index,]))
        
        if(percentChange > tol | i == 1) {
          wait=0
        }else {
          wait=wait+1
        }
        
      }else{
        
        wait=wait+1
        
      }
      
      if(show_train==1) {
        
        # Check Training
        if(i %% 1 == 0) {
          
          cat(" Epoch:", i, "Loss: ", loss$item(),", Val Loss: ",loss_oob$item(), "(PercentChange: ",round(percentChange,3),")", "\n")
          # cat(" Epoch:", i, "Loss: ", loss$item(),", Val Loss: ",loss_oob$item(), "\n")
          
        }
        
      }
      
      if(wait > patience) {
        if(show_train==1) {
          cat("Best Epoch at:", best_epoch, "\n")
        }
        break
      }
      
      loss$backward()  # Backpropagation step
      optimizer$step() # Update the parameters
      
    }
    
    #model$load_state_dict(state_best_model)
    return(best_model) 
    
  } # End BuildNN
  
  # =====================================================================================================
  ## MODEL AVERAGING
  # =====================================================================================================
  
  num_average <- nn_hyps$num_average
  sampling_rate <- nn_hyps$sampling_rate
  n_group = length(nn_hyps$x_pos) - length(nn_hyps$add_trends_to)
  opt_bootstrap <- nn_hyps$opt_bootstrap
  block_size <- nn_hyps$block_size
  variable_importance <- nn_hyps$variable_importance
  first_part <- nn_hyps$first_part
  VItoCheck <- which(sapply(variable_importance, is.null)==F)
  always_oob <- nn_hyps$always_oob
  
  pred.in.ensemble <- array(data = NA, dim = c(nrow(X),num_average))
  pred.ensemble <- array(data = NA, dim = c(nrow(Xtest),num_average))
  
  part.pred.in <- array(data = NA, dim = c(nrow(X),n_group,num_average))
  part.pred <- array(data = NA, dim = c(nrow(Xtest),n_group,num_average))
  
  trends.in <- array(data = NA, dim = c(nrow(X),length(nn_hyps$add_trends_to),num_average))
  trends <- array(data = NA, dim = c(nrow(Xtest),length(nn_hyps$add_trends_to),num_average))
  
  gaps.in <- array(data = NA, dim = c(nrow(X),n_group,num_average))
  gaps <- array(data = NA, dim = c(nrow(Xtest),n_group,num_average))
  
  if(length(VItoCheck) != 0) {
    
    pred.in.ensemble_VI <- array(data = NA, dim = c(nrow(X),max(lengths(variable_importance)),num_average,length(VItoCheck)))
    pred.ensemble_VI <- array(data = NA, dim = c(nrow(Xtest),max(lengths(variable_importance)),num_average,length(VItoCheck)))
    
    part.pred.in_VI <- array(data = NA, dim = c(nrow(X),max(lengths(variable_importance)),n_group,num_average,length(VItoCheck)))
    part.pred_VI <- array(data = NA, dim = c(nrow(Xtest),max(lengths(variable_importance)),n_group,num_average,length(VItoCheck)))
    
    trends.in_VI <- array(data = NA, dim = c(nrow(X),max(lengths(variable_importance)),length(nn_hyps$add_trends_to),num_average,length(VItoCheck)))
    trends_VI <- array(data = NA, dim = c(nrow(Xtest),max(lengths(variable_importance)),length(nn_hyps$add_trends_to),num_average,length(VItoCheck)))
    
    gaps.in_VI <- array(data = NA, dim = c(nrow(X),max(lengths(variable_importance)),n_group,num_average,length(VItoCheck)))
    gaps_VI <- array(data = NA, dim = c(nrow(Xtest),max(lengths(variable_importance)),n_group,num_average,length(VItoCheck)))
    
  }else{
    
    pred.in.ensemble_VI <- NA
    pred.ensemble_VI <- NA
    
    part.pred.in_VI <- NA
    part.pred_VI <- NA
    
    trends.in_VI <- NA
    trends_VI <- NA
    
    gaps.in_VI <- NA
    gaps_VI <- NA
    
  }
  
  if(show_train==2) {
    pb <- txtProgressBar(min = 0, max = num_average, style = 3) # Progress bar
  }
  
  trained_model <- list()
  for(j in 1:num_average) {
    
    if(opt_bootstrap==1) {
      
      # Bootstrap parameters
      if(!is.null(always_oob)) {
        sample_index <- c(1:nrow(X))[-always_oob]
        boot <- sample(sample_index, size = sampling_rate*length(sample_index), replace = F) # training
        oob <- sort(c(c(sample_index)[-boot],always_oob))# out of bag
      } else {
        sample_index <- c(1:nrow(X))
        boot <- sample(sample_index, size = sampling_rate*length(sample_index), replace = F) # training
        oob <- c(sample_index)[-boot]                                                        # out of bag
      }
      
      oos <- (nrow(X)+1):(nrow(X)+nrow(Xtest))                                                # out of sample
      
    }
    
    if(opt_bootstrap==2) {
      
      # Bootstrap parameters
      if(!is.null(always_oob)) {
        sample_index <- c(1:nrow(X))[-always_oob]
        groups<-sort(base::sample(x=c(1:(length(sample_index)/block_size)),size=length(sample_index),replace=TRUE))
        rando.vec <- rexp(rate=1,n=length(sample_index)/block_size)[groups] +0.1
        chosen.ones.plus<-rando.vec
        rando.vec<-which(chosen.ones.plus>quantile(chosen.ones.plus,1-sampling_rate))
        chosen.ones.plus<-sample_index[rando.vec]
        
        boot <- c(sort(chosen.ones.plus))                           # training
        oob <- sort(c(c(1:nrow(X))[-boot],always_oob))              # out of bag
        
      } else{
        
        sample_index <- c(1:nrow(X))
        groups<-sort(base::sample(x=c(1:(length(sample_index)/block_size)),size=length(sample_index),replace=TRUE))
        rando.vec <- rexp(rate=1,n=length(sample_index)/block_size)[groups] +0.1
        chosen.ones.plus<-rando.vec
        rando.vec<-which(chosen.ones.plus>quantile(chosen.ones.plus,1-sampling_rate))
        chosen.ones.plus<-sample_index[rando.vec]
        
        boot <- c(sort(chosen.ones.plus))                         # training
        oob <- c(1:nrow(X))[-boot]                                # out of bag
      }
      
      oos <- (nrow(X)+1):(nrow(X)+nrow(Xtest))                   # out of sample
      
    }
    
    if(sampling_rate == 1) {
      
      boot <- sample(1:nrow(X), size = 1*nrow(X), replace = F)     # training
      oob <- c(1:nrow(X))                                          # out of bag
      oos <- (nrow(X)+1):(nrow(X)+nrow(Xtest))                     # out of sample
      
    }
    
    ## Estimation -------------------------------------------------------------
    #--------------------------------------------------------------------------
    tic()
    model <- BuildNN(x_train,y_train,boot,nn_hyps)
    #trained_model[[j]] <- model
    
    
    ## Storage ----------------------------------------------------------------
    #--------------------------------------------------------------------------
    
    model$eval()
    
    with_no_grad({
      if(standardize==T) {
        
        pred.in.ensemble[oob,j] <- invert_scaling(as.matrix(model(x_train[oob,])[[1]]),temp)
        pred.ensemble[,j] <- invert_scaling(as.matrix(model(x_test)[[1]]),temp)
        
        part.pred.in[oob,,j] <- invert_scaling(as.matrix(model(x_train[oob,])[[2]][,]),temp) - temp$mu_y
        part.pred[,,j] <- invert_scaling(as.matrix(model(x_test)[[2]])[,],temp)  - temp$mu_y

        for(iii in 1:dim(trends)[2]){
          mean.save.adj=c(as.matrix(model(x_train[oob,])[[5]][iii])/as.matrix(model(x_train[-oob,])[[5]][iii]))[1]
          trends.in[oob,iii,j] <- mean.save.adj*as.matrix(model(x_train[oob,])[[3]])[,iii] 
          part.pred.in[oob,iii,j] <- mean.save.adj*c(invert_scaling(as.matrix(model(x_train[oob,])[[2]][,iii]),temp) - temp$mu_y)
          mean.save.adj=c(as.matrix(model(x_test[,])[[5]])[iii]/as.matrix(model(x_train[-oob,])[[5]])[iii])[1]
          
          part.pred[,iii,j] <- mean.save.adj*(invert_scaling(as.matrix(model(x_test)[[2]])[,iii],temp)  - temp$mu_y)
          trends[,iii,j] <- mean.save.adj*as.matrix(model(x_test)[[3]])[,iii]
        }
        
        gaps.in[oob,,j] <- invert_scaling(as.matrix(model(x_train[oob,])[[4]]),temp) - temp$mu_y
        gaps[,,j] <- invert_scaling(as.matrix(model(x_test)[[4]]),temp) - temp$mu_y
        
        # Check Variables importance
        if(length(VItoCheck) != 0 ) {
          
          for(ii in 1:length(VItoCheck)) {
            #cat('ii :',ii)
            for(jj in 1:length(variable_importance[[VItoCheck[ii]]])) {
              #cat('jj :',jj)
              
              model$eval()
              # set.seed(seed+jj+1000*ii)
              
              x_train_alt <- x_train$detach()$clone()
              x_test_alt <- x_test$detach()$clone()
              
              toShuffle <- unlist(lapply(1:length(first_part),
                                         function(x) which(varNames==paste0(first_part[x],variable_importance[[VItoCheck[ii]]][jj]))))
              sampling <- sample(1:x_train$size()[1], size = x_train$size()[1])
              sampling_test <- sample(1:x_test$size()[1], size = x_test$size()[1])
              
              
              for(kk in 1:length(toShuffle)) {
                #print(kk)
                alt <- x_train[sampling,toShuffle[kk]]
                alt_test <- x_test[sampling_test,toShuffle[kk]]
                
                x_train_alt[,toShuffle[kk]] <- alt
                x_test_alt[,toShuffle[kk]] <- alt_test
              }
              
              pred.in.ensemble_VI[oob,jj,j,ii] <- invert_scaling(as.matrix(model(x_train_alt[oob,])[[1]]),temp)
              pred.ensemble_VI[,jj,j,ii] <- invert_scaling(as.matrix(model(x_test_alt)[[1]]),temp)
              
              part.pred.in_VI[oob,jj,,j,ii] <- invert_scaling(as.matrix(model(x_train_alt[oob,])[[2]][,]),temp) - temp$mu_y
              part.pred_VI[,jj,,j,ii] <- invert_scaling(as.matrix(model(x_test_alt)[[2]])[,],temp)  - temp$mu_y
              
              mean.save.adj=c(as.matrix(model(x_train_alt[oob,])[[5]][ii])/as.matrix(model(x_train_alt[-oob,])[[5]][ii]))[1]
              trends.in_VI[oob,jj,,j,ii] <- mean.save.adj*as.matrix(model(x_train_alt[oob,])[[3]])[,ii] 
              part.pred.in_VI[oob,jj,,j,ii] <- mean.save.adj*c(invert_scaling(as.matrix(model(x_train_alt[oob,])[[2]][,ii]),temp) - temp$mu_y)
              mean.save.adj=c(as.matrix(model(x_test_alt[,])[[5]])[ii]/as.matrix(model(x_train_alt[-oob,])[[5]])[ii])[1]
              part.pred_VI[,jj,,j,ii] <- mean.save.adj*(invert_scaling(as.matrix(model(x_test_alt)[[2]])[,ii],temp)  - temp$mu_y)
              trends_VI[,jj,,j,ii] <- mean.save.adj*as.matrix(model(x_test_alt)[[3]])[,ii]
              
              gaps.in_VI[oob,jj,,j,ii] <- invert_scaling(as.matrix(model(x_train_alt[oob,])[[4]]),temp) - temp$mu_y
              gaps_VI[,jj,,j,ii] <- invert_scaling(as.matrix(model(x_test_alt)[[4]]),temp) - temp$mu_y
              
            }
          }
          
        } # Variables importance
        
      }else{
        
        pred.in.ensemble[oob,j] <-as.matrix(model(x_train[oob,])[[1]])
        pred.ensemble[,j] <- as.matrix(model(x_test)[[1]])
        
        part.pred.in[oob,,j] <- as.matrix(model(x_train[oob,])[[2]][,])
        part.pred[,,j] <- as.matrix(model(x_test)[[2]])[,]
        
        trends.in[oob,,j] <- as.matrix(model(x_train[oob,])[[3]])
        trends[,,j] <- as.matrix(model(x_test)[[3]])
        
        gaps.in[oob,,j] <- as.matrix(model(x_train[oob,])[[4]])
        gaps[,,j] <- as.matrix(model(x_test)[[4]])
        
      }
      
    }) #end with_no_grad
    
    model$train()
    
    if(show_train==2) {
      setTxtProgressBar(pb, j)
    }
    
    
    if(show_train==4) {
      cat("Done with model :",j,"\n \n")
      toc()
    }
    
    # Garbage Collector
    rm(model)
    gc()
    
  } # j, bootstrap end
  
  if(show_train==2) {
    close(pb)
  }
  
  pred.in <- rowMeans(pred.in.ensemble, na.rm = T)
  pred <- rowMeans(pred.ensemble, na.rm = T)
  
  # Rescale output
  ab <-  coef(lm(Y.ori~pred.in))
  
  results <- list(pred.in.ensemble=pred.in.ensemble*ab[2],
                  pred.ensemble=pred.ensemble*ab[2],
                  pred.in=pred.in*ab[2],
                  pred=pred*ab[2],
                  part.pred=part.pred*ab[2],
                  part.pred.in=part.pred.in*ab[2],
                  trends.in=trends.in,
                  trends=trends,
                  gaps.in=gaps.in*ab[2],
                  gaps=gaps*ab[2],
                  part.pred.in_VI=part.pred.in_VI,
                  part.pred_VI=part.pred_VI,
                  gaps.in_VI=gaps.in_VI,
                  gaps_VI=gaps_VI,
                  standardize=standardize,
                  scaler=temp)
  
  return(results)
  
} # FUNCTION END

# =====================================================================================================
## STANDARDIZATION
# =====================================================================================================

scale_data <- function(Xtrain, Ytrain, Xtest, Ytest) {
  
  # Features
  sigma_x <- apply(Xtrain,2,sd)
  mu_x <- apply(Xtrain,2,mean)
  
  if(is.null(dim(Xtest))==TRUE) {
    dim(Xtest) <- c(1, length(Xtest))
  }
  
  Xtest <- do.call(cbind,lapply(1:length(mu_x),function(x) (Xtest[,x] - mu_x[x])/sigma_x[x]))
  Xtrain <- do.call(cbind,lapply(1:length(mu_x),function(x) (Xtrain[,x] - mu_x[x])/sigma_x[x]))
  
  # Target
  sigma_y <- sd(Ytrain)
  mu_y <- mean(Ytrain)
  
  Ytrain <- (Ytrain-mu_y)/sigma_y
  Ytest <- (Ytest-mu_y)/sigma_y
  
  return(list(Xtrain = Xtrain, Ytrain = Ytrain, Xtest = Xtest, Ytest = Ytest , sigma_y = sigma_y, mu_y = mu_y,
              sigma_x = sigma_x, mu_x = mu_x))
  
}

invert_scaling <- function(scaled, scaler){
  
  sigma_y <- scaler$sigma_y
  mu_y <- scaler$mu_y
  
  
  inverted <- sigma_y*scaled + mu_y
  
  return(inverted)
  
}

rescale_data <- function(results,newx) {
  
  # Features
  sigma_x <- results$scaler$sigma_x
  mu_x <- results$scaler$mu_x
  
  if(is.null(dim(newx))==TRUE) {
    dim(newx) <- c(1, length(newx))
  }
  
  Xtest <- do.call(cbind,lapply(1:length(mu_x),function(x) (newx[,x] - mu_x[x])/sigma_x[x]))
  
  return(newx = Xtest)
  
}