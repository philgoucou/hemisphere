
## INITIALIZATION ---------------------------------------------------------------------------------------------------
# ===================================================================================================================

rm(list = ls())

path = "~/Dropbox/Amnesic_NN/MacroNN/exemple/R/" #MNN_example/"
setwd(path)

# Array of packages to be checked and installed if not already
myPKGs <- c('torch', 'stringr','pracma','ggplot2','reshape2','tidyr',
            'pracma','fGarch','packager')

# check to see if each package is installed, and if not add it to a list to install
InstalledPKGs <- names(installed.packages()[,'Package'])
InstallThesePKGs <- myPKGs[!myPKGs %in% InstalledPKGs]

# install any needed packages
if (length(InstallThesePKGs) > 0) install.packages(InstallThesePKGs, repos = "http://cran.us.r-project.org")

# Load packages
library(torch)
library(stringr)
library(pracma)
library(ggplot2)
library(reshape2)
library(tidyr)
library(pracma)
library(fGarch)
library(packager)
torch_set_num_threads(1)

# Plots functions
scaleFUN <- function(x) sprintf("%.2f", x)

recessions.df = read.table(textConnection(
  "Peak, Trough
    1960-04-01, 1961-02-01
    1969-12-01, 1970-11-01
    1973-11-01, 1975-03-01
    1980-01-01, 1980-07-01
    1981-07-01, 1982-11-01
    1990-07-01, 1991-03-01
    2001-03-01, 2001-11-01
    2007-12-01, 2009-06-01,
    2020-03-01, 2020-06-01"), sep=',',
  colClasses=c('Date', 'Date'), header=TRUE)

date_allSample <- seq.Date(as.Date('1961-06-01'), 
                           as.Date('2024-03-01'), 
                           by = "quarter")

## LOAD HNN FUNCTION -------------------------------------------------------------------------------------------------
# ====================================================================================================================

source("HNN_function.R")

## LOAD DATA ---------------------------------------------------------------------------------------------------------
# ====================================================================================================================

newtrain <- read.csv(file = "data_for_2024Q1.csv")
rownames(newtrain) <- as.character(newtrain$Date)
newtrain <- newtrain[,-1]

## Make Train and Test sets ---------------------------------------

end <- "12/1/2019" # In-sample ends
newtrain <- data.frame(newtrain)
train_index <- 1:((which(rownames(newtrain)==end)))
train_data <- newtrain[train_index,]
test_data <- newtrain[-train_index,]

form <- formula(y ~ .)
X <- model.matrix(form, data=train_data)[,-1]     # 1961Q2-2019Q4
Y <- train_data$y
Xtest <- model.matrix(form, data=test_data)[,-1]  # 2020Q1-2022Q3
Ytest <- test_data$y
oos.index <- (nrow(X))


## MAKE HEMISPHERES --------------------------------------------------------------------------------------------------
# ====================================================================================================================

# Which lags to use ?
first_part <- c("L0_","L1_","L2_","L3_","L1_MARX_","L3_MARX_","L7_MARX_")


# Real activity
labor_name <- c("PAYEMS","USPRIV","MANEMP","SRVPRD","USGOOD" ,"DMANEMP","NDMANEMP","USCONS","USEHS",
                "USFIRE","USINFO","USPBS","USLAH","USSERV","USMINE","USTPU","USGOVT","USTRADE",
                "USWTRADE","CES9091000001","CES9092000001","CES9093000001","CE16OV","CIVPART",
                "UNRATE","UNRATESTx","UNRATELTx","LNS14000012","LNS14000025","LNS14000026",
                "UEMPLT5","UEMP5TO14","UEMP15T26","UEMP27OV","LNS13023621","LNS13023557",
                "LNS13023705","LNS13023569","LNS12032194","HOABS","HOAMS","HOANBS","AWHMAN",
                "AWHNONAG","AWOTMAN","HWIx","UEMPMEAN","CES0600000007", "HWIURATIOx","CLAIMSx",
                "GDPC1","PCECC96","GPDIC1","OUTNFB","OUTBS","OUTMS","INDPRO","IPFINAL","IPCONGD",
                "IPMAT","IPDMAT","IPNMAT","IPDCONGD","IPB51110SQ","IPNCONGD","IPBUSEQ","IPB51220SQ",
                "TCU","CUMFNS","IPMANSICS","IPB51222S","IPFUELS")

x_pos1 <- unlist(lapply(1:length(first_part),
                        function(i) unlist(lapply(1:length(labor_name),
                                                  function(x) which(colnames(X)==paste0(first_part[i],labor_name[x]))))))

# Short-Run Expectations
colnames(X)[1:4] <- c("L0_Y","L1_Y","L2_Y","L3_Y")
colnames(Xtest)[1:4] <- c("L0_Y","L1_Y","L2_Y","L3_Y")
price_name <- c("Y","PCECTPI","PCEPILFE","GDPCTPI","GPDICTPI","IPDBS",
                "CPILFESL","CPIAPPSL",
                "CPITRNSL","CPIMEDSL","CUSR0000SAC","CUSR0000SAD","WPSFD49207",
                "PPIACO","WPSFD49502","WPSFD4111","PPIIDC","WPSID61","WPSID62",
                "CUSR0000SAS","CPIULFSL","CUSR0000SA0L2","CUSR0000SA0L5","CUSR0000SEHC",
                "spf_cpih1","spf_cpi_currentYrs","inf_mich")

x_pos2 <- unlist(lapply(1:length(first_part),
                        function(i) unlist(lapply(1:length(price_name),
                                                  function(x) which(colnames(X)==paste0(first_part[i],price_name[x]))))))

# Commodities
commodities_name <- c("WPU0531",
                      "WPU0561","OILPRICEx","PPICMM")

x_pos3 <- unlist(lapply(1:length(first_part),
                        function(i) unlist(lapply(1:length(commodities_name),
                                                  function(x) which(colnames(X)==paste0(first_part[i],commodities_name[x]))))))

# Long-run Expectations
x_pos4 <- c(ncol(X)) # linear trend


## MODEL ESTIMATION --------------------------------------------------------------------------------------------------
# ====================================================================================================================

## Set hyperparameters --------------------------------

# Uncomment to see VI from the corresponding hemisphere 
variable_importance <- vector("list",length = 3)
# variable_importance[[1]] <- labor_name
# variable_importance[[2]] <- price_name
# variable_importance[[3]] <- commodities_name

x_pos <- list()
x_pos[[1]] <- x_pos1 # Real activity hemisphere
x_pos[[2]] <- x_pos2 # SR Expectations hemisphere
x_pos[[3]] <- x_pos3 # Commodities hemisphere
x_pos[[4]] <- x_pos4 # LR Expectations hemisphere
x_pos[[5]] <- x_pos4 # Trend(time varying coefficient) associate to hemisphere 1
x_pos[[6]] <- x_pos4 # Trend(time varying coefficient) associate to hemisphere 2
x_pos[[7]] <- x_pos4 # Trend(time varying coefficient) associate to hemisphere 3

nodes <- list()
nodes[[1]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 1
nodes[[2]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 2
nodes[[3]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 3
nodes[[4]] <- rep(400,3) # Number of neurons and hidden layers in hemisphere 4
nodes[[5]] <- rep(100,3) # Number of neurons and hidden layers for the trend in hemisphere 1
nodes[[6]] <- rep(100,3) # Number of neurons and hidden layers for the trend in hemisphere 2
nodes[[7]] <- rep(100,3) # Number of neurons and hidden layers for the trend in hemisphere 3

nn_hyps <- list(n_features=c(length(x_pos1),
                             length(x_pos2),
                             length(x_pos3),
                             length(x_pos4),
                             length(x_pos4),
                             length(x_pos4),
                             length(x_pos4)),
                nodes=nodes,             
                patience=50,              # Number of epochs before stopping once your loss starts to increase (Return the best model)
                epochs=500,               # Maximum number of epochs
                lr= 0.001,                # Learning rate
                show_train=2,             # 1=show each bootstrap loss, 2=progress bar, 3+=show nothing
                num_average=50,           # Number of bootstrap
                sampling_rate = 0.65,     # In-sample sampling rate
                x_pos = x_pos,            
                tol = 0.01,               # Early stopping criteria tolerance
                dropout_rate=0.2,         # Dropout rate in each layers
                block_size=8,             
                opt_bootstrap=2,         
                add_trends_to=c(1:3),     # Add trend (time varying coefficient) to hemispheres 1 to 3
                variable_importance=variable_importance, 
                first_part=first_part,
                always_oob = NULL)  # Rows to always include in OOB

## Estimation ------------------------------------------------

s <- Sys.time()

model <- HNN(X,Y,Xtest,Ytest,nn_hyps,standardize=T,seed=1234)

e <- Sys.time()

print(e-s)


## RESULTS ---------------------------------------------------------------------------------------------------------
# ==================================================================================================================

## Fitted values and forecasts -----------------------------------------------------------------------

# All sample
pred <- data.frame(c(model$pred.in,model$pred),Realized=c(Y,Ytest))*400
rownames(pred) <- as.Date(c(rownames(X),rownames(Xtest)), tryFormats = "%m/%d/%Y")
colnames(pred) <- c("HNN","Realized")
pred <- as.matrix(pred)

test.long <- reshape2::melt(pred)
test.long$Var1 =  as.Date(test.long$Var1)

p=ggplot() +
  geom_line(data = test.long[test.long$Var2=="HNN",], 
            aes(x =Var1 , y =value,color=Var2), size = 1.5)+ 
  geom_line(data = test.long[test.long$Var2=="Realized",],
            aes(x =Var1 , y =value,color=Var2), size = 1)+
  theme_bw()+
  xlab('Date')+ylab('Annualized Inflation rate (%)')+labs(color='')+
  ggtitle("All Sample") +
  geom_vline(xintercept =date_allSample[oos.index[1]],linetype="dashed",size=1)+
  theme(axis.text = element_text(size=18),
        axis.title=element_text(size=15),
        strip.text = element_text(face="bold", size=18),
        legend.text=element_text(size=18),
        legend.position='bottom',
        plot.title=element_text(family='', face='bold', size=18)) +
  scale_color_manual(values=c("red","black")) + 
  geom_rect(data=subset(recessions.df, Peak >= min(test.long$Var1)),
            inherit.aes=FALSE,aes(xmin=Peak, xmax=Trough,
                                  ymin=-Inf, ymax=+Inf), fill='pink', alpha=0.3) +
  coord_cartesian(ylim = c(-9,15))
p

# Form 2015Q1
pred <- data.frame(c(model$pred.in,model$pred),Realized=c(Y,Ytest))*400
rownames(pred) <- as.Date(c(rownames(X),rownames(Xtest)), tryFormats = "%m/%d/%Y")
colnames(pred) <- c("HNN","Realized")
pred <- as.matrix(pred)

test.long <- reshape2::melt(pred)
test.long$Var1 =  as.Date(test.long$Var1)

p=ggplot() +
  geom_line(data = test.long[test.long$Var2=="HNN",], 
            aes(x =Var1 , y =value,color=Var2), size = 1.5)+ 
  geom_line(data = test.long[test.long$Var2=="Realized",],
            aes(x =Var1 , y =value,color=Var2), size = 1)+
  theme_bw()+
  xlab('Date')+ylab('Annualized Inflation rate (%)')+labs(color='')+
  ggtitle("Forecast from 2015Q1", ) +
  geom_vline(xintercept =date_allSample[oos.index[1]],linetype="dashed",size=1)+
  theme(axis.text = element_text(size=18),
        axis.title=element_text(size=15),
        strip.text = element_text(face="bold", size=18),
        legend.text=element_text(size=18),
        legend.position='bottom',
        plot.title=element_text(family='', face='bold', size=18)) +
  scale_color_manual(values=c("red","black")) + 
  geom_rect(data=subset(recessions.df, Peak >= min(test.long$Var1)),
            inherit.aes=FALSE,aes(xmin=Peak, xmax=Trough,
                                  ymin=-Inf, ymax=+Inf), fill='pink', alpha=0.3) +
  coord_cartesian(ylim = c(-9,15), xlim = as.Date(c("2015-03-01","2024-04-01")))
p

## Contributions ------------------------------------------------------------------------------------------

# Real Activity
alt <- rbind(model$part.pred.in[,1,],model$part.pred[,1,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- rowMeans((rbind(model$part.pred.in[,1,],model$part.pred[,1,])),na.rm = TRUE)*400
df <- gather(data.frame("Real Activity"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df1 <- cbind(df,date,df_quantile)

# Short-Run Expectations
alt <- rbind(model$part.pred.in[,2,],model$part.pred[,2,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- rowMeans((rbind(model$part.pred.in[,2,],model$part.pred[,2,])),na.rm = TRUE)*400
df <- gather(data.frame("SR Expectations"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df2 <- cbind(df,date,df_quantile)

# Commodities
alt <- rbind(model$part.pred.in[,3,],model$part.pred[,3,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- rowMeans((rbind(model$part.pred.in[,3,],model$part.pred[,3,])),na.rm = TRUE)*400
df <- gather(data.frame(Commodities=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df3 <- cbind(df,date,df_quantile)

# Long-Run Expectations (trend)
alt <- rbind(model$part.pred.in[,4,],model$part.pred[,4,]) + mean(Y)
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- (rowMeans((rbind(model$part.pred.in[,4,],model$part.pred[,4,])),na.rm = TRUE) + mean(Y))*400
df <- gather(data.frame("LR Expectations"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df4 <- cbind(df,date,df_quantile)

alt <- as.data.frame(rbind(df1,df2,df3,df4))

alt[which(alt[,1] == "Real.Activity"),1] <- "Real Activity"
alt[which(alt[,1] == "SR.Expectations"),1] <- "SR Expectations"
alt[which(alt[,1] == "LR.Expectations"),1] <- "LR Expectations"

data.long <- alt
data.long[,1] <- factor(data.long[,1], levels = c("Real Activity","SR Expectations","Commodities","LR Expectations"))

p=ggplot(data = data.long, 
         mapping = aes(x = Date, y =value, color= Group)) +
  geom_line(size=1.5)+
  facet_wrap(~(Group), ncol = 2, scales = 'free') +
  geom_ribbon(aes(ymin=Min, ymax=Max), 
              alpha = 0.30, colour = NA) +  
  theme_bw()+
  xlab('')+ylab('')+labs(color='')+
  scale_x_date(breaks = scales::pretty_breaks(n = 8),date_labels = "%Y", expand = c(0.01,0.01))+
  geom_vline(xintercept =date_allSample[oos.index[1]],linetype="dashed",size=1.35)+
  geom_hline(yintercept =0,size=c(0.6,0.6,0.6,0.6),colour=c('grey29','grey29','grey29','white'))+
  scale_color_manual(values=c("#ef3b2c","#386cb0","#fdb462","forest green"))+
  theme(axis.text.x=element_text(size=24,angle = 0,hjust=1),
        axis.text.y=element_text(size=24),
        strip.text = element_text(face="bold", size=30),
        legend.text=element_text(size=30),
        legend.position='bottom'
  ) +
  geom_rect(data=subset(recessions.df, Peak >= min(data.long$Date)),
            inherit.aes=FALSE,aes(xmin=Peak, xmax=Trough,
                                  ymin=-Inf, ymax=+Inf), fill='pink', alpha=0.3)

p

## Coefficients --------------------------------------------------------------------------------------------

# Real Activity
alt <- rbind(model$trends.in[,1,],model$trends[,1,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))
alt <- rowMeans((rbind(model$trends.in[,1,],model$trends[,1,])),na.rm = TRUE)
df <- gather(data.frame("Real Activity"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df1 <- cbind(df,date,df_quantile)

# Short-Run Expectations
alt <- rbind(model$trends.in[,2,],model$trends[,2,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))
alt <- rowMeans((rbind(model$trends.in[,2,],model$trends[,2,])),na.rm = TRUE)
df <- gather(data.frame("SR Expectations"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df2 <- cbind(df,date,df_quantile)

# Commodities
alt <- rbind(model$trends.in[,3,],model$trends[,3,])
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))
alt <- rowMeans((rbind(model$trends.in[,3,],model$trends[,3,])),na.rm = TRUE)
df <- gather(data.frame(Commodities=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df3 <- cbind(df,date,df_quantile)

# Long-Run Expectations (trend)
alt <- rbind(model$part.pred.in[,4,],model$part.pred[,4,]) + mean(Y)
quantile <- do.call(rbind,lapply(1:nrow(alt),function(x) quantile(alt[x,],probs=c(0.16,0.84), na.rm = T)))*400
alt <- (rowMeans((rbind(model$part.pred.in[,4,],model$part.pred[,4,])),na.rm = TRUE) + mean(Y))*400
df <- gather(data.frame("LR Expectations"=alt), key = "Group")
df_quantile <- data.frame(Min=quantile[,1],Max=quantile[,2])
date <- data.frame(Date=as.Date(date_allSample))
df4 <- cbind(df,date,df_quantile)

alt <- as.data.frame(rbind(df1,df2,df3,df4))

alt[which(alt[,1] == "Real.Activity"),1] <- "Real Activity"
alt[which(alt[,1] == "SR.Expectations"),1] <- "SR Expectations"
alt[which(alt[,1] == "LR.Expectations"),1] <- "LR Expectations"

data.long <- alt
data.long[,1] <- factor(data.long[,1], levels = c("Real Activity","SR Expectations","Commodities","LR Expectations"))

p=ggplot(data = data.long, 
         mapping = aes(x = Date, y =value, color= Group)) +
  geom_line(size=1.5)+
  facet_wrap(~(Group), ncol = 2, scales = 'free') +
  geom_ribbon(aes(ymin=Min, ymax=Max), 
              alpha = 0.30, colour = NA) +  
  theme_bw()+
  xlab('')+ylab('')+labs(color='')+
  scale_x_date(breaks = scales::pretty_breaks(n = 8),date_labels = "%Y", expand = c(0.01,0.01))+
  geom_vline(xintercept =date_allSample[oos.index[1]],linetype="dashed",size=1.35)+
  geom_hline(yintercept =0,size=c(0.6,0.6,0.6,0.6),colour=c('grey29','grey29','grey29','white'))+
  scale_color_manual(values=c("#ef3b2c","#386cb0","#fdb462","forest green"))+
  theme(axis.text.x=element_text(size=24,angle = 0,hjust=1),
        axis.text.y=element_text(size=24),
        strip.text = element_text(face="bold", size=30),
        legend.text=element_text(size=30),
        legend.position='bottom'
  ) +
  geom_rect(data=subset(recessions.df, Peak >= min(data.long$Date)),
            inherit.aes=FALSE,aes(xmin=Peak, xmax=Trough,
                                  ymin=-Inf, ymax=+Inf), fill='pink', alpha=0.3)

p